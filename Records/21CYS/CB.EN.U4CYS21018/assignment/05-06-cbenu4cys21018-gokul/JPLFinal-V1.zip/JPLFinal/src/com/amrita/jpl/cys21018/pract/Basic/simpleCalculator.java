package com.amrita.jpl.cys21018.pract.Basic;

import java.util.Scanner;

/** 
 * simple calculator
 */

public class simpleCalculator {
    public static void main(String[] args) {
        
        int a, b;
        char operation;
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter value for integer a: ");
        a = sc.nextInt();
        System.out.println("Enter value for integer b: ");
        b = sc.nextInt();
        System.out.println("Enter the operation to perform [+, -, *, /] : ");
        operation = sc.next().charAt(0);
        
        switch (operation) {
            case '+':
                System.out.println("The sum of numbers is : " + a+b);
                break;
                
            case '-':
                System.out.println("The difference of numbers is : " + (a-b));
                break;
                
            case '*':
                System.out.println("The product of the numbers is : " + (a*b));
                break;
            
            case '/':
                if (b == 0) {
                    System.out.println("Cant divide when b = 0");
                    break;
                }
                System.out.println("The quotient is : " + (a / b));
                break;
                
            default:
                System.out.println("Enter a valid option and try again!");
        }
    }
}

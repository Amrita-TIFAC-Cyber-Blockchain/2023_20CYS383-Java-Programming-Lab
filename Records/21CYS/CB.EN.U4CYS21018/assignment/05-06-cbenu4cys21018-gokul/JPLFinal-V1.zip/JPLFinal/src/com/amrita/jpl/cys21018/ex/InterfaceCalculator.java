package com.amrita.jpl.cys21018.ex;

import java.util.Scanner;

/**
 * defined an interface Calculator with four methods add, subtract, multiply and divide
 * @param num1 
 * @param num2
 * @return num1 + num2 for add method, num1 - num2 for subtract method, num1 * num2 for multiply method, num1 / num2 for divide method
 */
interface Calculator {
    double add(double num1, double num2);
    double subtract(double num1, double num2);
    double multiply(double num1, double num2);
    double divide(double num1, double num2);
    
}

/**
 * create a BasicCalculator class which implements Calculator interface
 * and define the four methods
 * add, subtract, multiply and divide
 * divide method throws an ArithmeticException if the second number is zero
 * and prints "Division by zero error!"
 * and returns -1
 * @param num1
 * @param num2
 * @return num1 + num2 for add method, num1 - num2 for subtract method, num1 * num2 for multiply method, num1 / num2 for divide method, -1 for divide method if num2 is zero
 */
class BasicCalculator implements Calculator {
    public double add(double num1, double num2) {
        return num1 + num2;
    }
    public double subtract(double num1, double num2) {
        return num1 - num2;
    }
    public double multiply(double num1, double num2) {
        return num1 * num2;
    }
    public double divide(double num1, double num2) {
        if (num2 == 0) {
            System.out.println("Division by zero error!");
            return -1;}
        return num1 / num2;
        
    }
}

/**
 * create a main class to test the BasicCalculator class
 * and print the results of the four methods
 * @param num1
 * @param num2
 * @return num1 + num2 for add method, num1 - num2 for subtract method, num1 * num2 for multiply method, num1 / num2 for divide method, -1 for divide method if num2 is zero
 */

public class InterfaceCalculator {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double num1, num2;
        num1 = input.nextDouble();
        num2 = input.nextDouble();
        BasicCalculator calc = new BasicCalculator();
        System.out.println("Addition: " + calc.add(num1, num2));
        System.out.println("Subtraction: " + calc.subtract(num1, num2));
        System.out.println("Multiplication: " + calc.multiply(num1, num2));
        // try and catch block to handle divide by zero exception
        try {
            System.out.println("Division: " + calc.divide(num1, num2));
        } catch (ArithmeticException e) {
            System.out.println("Division by zero error!");
            System.out.println("Division: -1") ;
        }
    }
}
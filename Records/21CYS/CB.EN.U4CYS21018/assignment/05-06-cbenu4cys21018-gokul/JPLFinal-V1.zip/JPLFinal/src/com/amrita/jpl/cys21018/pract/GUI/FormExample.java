package com.amrita.jpl.cys21018.pract.GUI;

import javax.swing.*;
import java.awt.*;

/** 
 * Sample Form with Labels and Inputs
 * used JLabel, JTextField
 * used GridLayout
 */

public class FormExample extends JFrame {
    public FormExample () {
        setTitle("Sample Form with Labels and Inputs");
        setSize(600, 900);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        setLayout(new GridLayout(8,2));
    
        JLabel firstName = new JLabel("First Name", JLabel.CENTER);
        JLabel lastName = new JLabel("Last Name", JLabel.CENTER);
        JLabel rollNo = new JLabel("Roll Number", JLabel.CENTER);
        JLabel mobile = new JLabel("Mobile Number", JLabel.CENTER);
        JLabel email = new JLabel("Email ID:", JLabel.CENTER);
        JLabel gender = new JLabel("Gender", JLabel.CENTER);
        JLabel collageName = new JLabel("Collage Name", JLabel.CENTER);
        JLabel hobby = new JLabel("Hobby", JLabel.CENTER);
    
        JTextField firstNameInput = new JTextField("");
        JTextField lastNameInput = new JTextField("");
        JTextField rollNoInput = new JTextField("");
        JTextField mobileInput = new JTextField("");
        JTextField emailInput = new JTextField("");
        JTextField genderInput = new JTextField("");
        JTextField collageNameInput = new JTextField("");
        JTextField hobbyInput = new JTextField("");
        
        add(firstName);
        add(firstNameInput);
        add(lastName);
        add(lastNameInput);
        add(rollNo);
        add(rollNoInput);
        add(mobile);
        add(mobileInput);
        add(email);
        add(emailInput);
        add(gender);
        add(genderInput);
        add(collageName);
        add(collageNameInput);
        add(hobby);
        add(hobbyInput);
        
        setVisible(true);
    }
    
    public static void main(String[] args) {
        new FormExample();
    }
}

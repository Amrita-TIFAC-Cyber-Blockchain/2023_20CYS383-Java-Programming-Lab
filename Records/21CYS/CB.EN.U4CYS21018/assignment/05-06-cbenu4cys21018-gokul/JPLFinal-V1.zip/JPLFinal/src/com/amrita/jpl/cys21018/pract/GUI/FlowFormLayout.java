package com.amrita.jpl.cys21018.pract.GUI;

import javax.swing.*;
import java.awt.*;

/**
 * Form using Flow Layout
 * used JLabel, JTextField, JButton
 * used FlowLayout
 */

public class FlowFormLayout extends JFrame {
    public FlowFormLayout() {
        setTitle("Form using Flow Layout");
        setSize(200, 900);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        setLayout(new FlowLayout());
        
        JLabel firstName = new JLabel("First Name", JLabel.CENTER);
        JLabel lastName = new JLabel("Last Name", JLabel.CENTER);
        JLabel rollNo = new JLabel("Roll Number", JLabel.CENTER);
        JLabel mobile = new JLabel("Mobile Number", JLabel.CENTER);
        JLabel email = new JLabel("Email ID:", JLabel.CENTER);
        JLabel gender = new JLabel("Gender", JLabel.CENTER);
        JLabel collageName = new JLabel("Collage Name", JLabel.CENTER);
        JLabel hobby = new JLabel("Hobby", JLabel.CENTER);
    
        JTextField firstNameInput = new JTextField("Gokul");
        JTextField lastNameInput = new JTextField("Lenin");
        JTextField rollNoInput = new JTextField("18");
        JTextField mobileInput = new JTextField("9617340354");
        JTextField emailInput = new JTextField("gokul2003g@gmail.com");
        JTextField genderInput = new JTextField("Male");
        JTextField collageNameInput = new JTextField("Amrita");
        JTextField hobbyInput = new JTextField("All");
    
        JButton submitButton = new JButton("Submit");

        add(firstName);
        add(firstNameInput);
        add(lastName);
        add(lastNameInput);
        add(rollNo);
        add(rollNoInput);
        add(mobile);
        add(mobileInput);
        add(email);
        add(emailInput);
        add(gender);
        add(genderInput);
        add(collageName);
        add(collageNameInput);
        add(hobby);
        add(hobbyInput);
        add(submitButton);
        
        setVisible(true);

    }
    public static void main(String[] args) {
        new FlowFormLayout();
    }
}

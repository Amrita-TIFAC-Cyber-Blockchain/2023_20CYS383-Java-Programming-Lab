import javax.swing.*;
import java.awt.*;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Scanner;

/**
 * using packages java swing for the GUI
 * and java io for the file reader and writer
 * Main class extends JFrame for importing the GUI modules
 */

public class Main extends JFrame {
    public static void main(String[] args) {
        
        /**
         * Create a simple GUI window with text area, load and save buttons
         * Using JFrame class to create the frame
         * Using BorderLayout to set the layout of the frame
         * set the size of the frame to 500x500 px
         */
        
        // Create a simple GUI window with text area, load and save buttons
        JFrame frame = new JFrame("Text Editor");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setTitle("Java Swing Simple Text Editor");
        frame.setSize(500, 500);
        frame.setLayout(new BorderLayout());
        frame.setVisible(true);
        
        /**
         * Using JTextArea to create the text area
         * Add the text area to the frame in the center
         */
        
        JTextArea textArea = new JTextArea();
        frame.add(textArea, BorderLayout.CENTER);
        
        /**
         * Using JButton to create the load and save buttons
         */
        
        JButton loadButton = new JButton("Load");        
        JButton saveButton = new JButton("Save");

        /** 
         * add buttons adjacent to each other
         * using JPanel to create a panel
         * add the buttons to the frame in the south
         */
        
        JPanel panel = new JPanel();
        panel.add(loadButton);
        panel.add(saveButton);
        frame.add(panel, BorderLayout.SOUTH);
        
        /**
         * FileWriter used to write the text in the text area to a file
         * put it in a try catch block to handle exceptions
         * save the text in the text area to a file text.txt 
         */
        

        saveButton.addActionListener(e -> {
            try {
                /**
                 * ask the user to enter the file name in a dialog box
                 * create a file with the name entered by the user
                 */
                String fileName = JOptionPane.showInputDialog("Enter the file name without extension");
                FileWriter writer = new FileWriter(fileName + ".txt");
                writer.write(textArea.getText());
                writer.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });
        
        /**
         * FileReader used to read the text from a file
         * put it in a try catch block to handle exceptions
         * read the text from the file text.txt and append it to the text area
         */
 
        loadButton.addActionListener(e -> {
            try {
                /**
                 * ask the user to enter the file name to load from in a dialog box
                 * read the text from the file entered by the user and append it to the text area
                 */
                String fileName = JOptionPane.showInputDialog("Enter the file name without extension");
                // add icons to the dialog box
                Scanner scanner = new Scanner(new FileReader(fileName + ".txt"));
                while (scanner.hasNextLine()) {
                    /**
                     * overwrite the text in the text area with the text from the file
                     */
                    textArea.setText("");
                    textArea.append(scanner.nextLine());
                }
                scanner.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });
    }
}
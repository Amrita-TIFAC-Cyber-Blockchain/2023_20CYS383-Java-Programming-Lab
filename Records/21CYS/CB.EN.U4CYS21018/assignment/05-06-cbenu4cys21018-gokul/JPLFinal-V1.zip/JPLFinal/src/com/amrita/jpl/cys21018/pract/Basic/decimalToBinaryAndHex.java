package com.amrita.jpl.cys21018.pract.Basic;

import java.util.Scanner;

/** 
 * convert decimal to binary and hexadecimal
 */

public class decimalToBinaryAndHex {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter the integeral value to convert to binary and hex: ");
        int decimal = input.nextInt();
    
        System.out.println("The binary value is: " + Integer.toBinaryString(decimal));
        System.out.println("The hexadecimal value is: " + Integer.toHexString(decimal));
        
    }
}

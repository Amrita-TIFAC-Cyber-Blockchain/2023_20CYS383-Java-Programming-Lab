import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

/**
 * File Management System
 * This program is a simple file management system that allows the user to add, edit, and delete files.
 */

public class FileManagementSystem extends JFrame {
    private JTable fileTable;
    private DefaultTableModel tableModel;
    private JTextField fileName;
    private JTextField fileSize;
    private JTextField fileType;
    private JButton addButton;
    private JButton deleteButton;
    private JButton refreshButton;
    
    private List<File> lists;
    
    /**
     * Constructor.
     */
    
    public FileManagementSystem() {
        lists = new ArrayList<>();
        
        setTitle("21UCYS End Semester Assignment File Manager");
        setSize(600, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        createComponents();
        addComponentsToFrame();
    }
    
    /**
     * Create the components of the frame.
     */
    
    private void createComponents() {
        // Table
        tableModel = new DefaultTableModel();
        tableModel.addColumn("File Name");
        tableModel.addColumn("File Size");
        tableModel.addColumn("File Type");
        fileTable = new JTable(tableModel);
        
        /** 
         * Buttons
         */
        addButton = new JButton("Add File");
        deleteButton = new JButton("Edit File");
        refreshButton = new JButton("Delete Button");
        
        /**
         * Form fields
         */
        fileName = new JTextField(20);
        fileSize = new JTextField(20);
        fileType = new JTextField(20);
        
        /**
         * Button actions
         */
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addFile();
            }
        });
        
        deleteButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                deleteFile();
            }
        });
        
        refreshButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                refreshFile();
            }
        });
    }
    
    /**
     * Add the components to the frame.
     */
    private void addComponentsToFrame() {
        // Main layout
        setLayout(new BorderLayout());
        
        /**
         * Create a panel for the form fields
         * and add the form fields to the panel.
         */
        
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridLayout(1, 6));
        formPanel.add(new JLabel("File Name:"));
        formPanel.add(fileName);
        formPanel.add(new JLabel("File Size:"));
        formPanel.add(fileSize);
        formPanel.add(new JLabel("File Type:"));
        formPanel.add(fileType);
        
        // Create a panel for the buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(addButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(refreshButton);
        
        // Add the table, form, and button panels to the frame
        add(new JScrollPane(fileTable), BorderLayout.CENTER);
        add(formPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.SOUTH);
    }
    
    private void addFile() {
        String filename = fileName.getText();
        String filesize = fileSize.getText();
        String filetype = fileType.getText();
        
        if (filename.isEmpty()) {
            showErrorDialog("Please enter a name.");
            return;
        }
        
        if (!isValidSize(filesize)) {
            showErrorDialog("Invalid size.");
            return;
        }
        
        if (!isValidType(filetype)) {
            showErrorDialog("Invalid format.");
            return;
        }
        
        File file = new File(filename, filesize, filetype);
        lists.add(file);
        tableModel.addRow(new Object[]{file.getName(), file.getFileSize(), file.getFileType()});
        clearFormFields();
    }
    
    private void deleteFile() {
        int selectedRow = fileTable.getSelectedRow();
        
        if (selectedRow == -1) {
            showErrorDialog("Please select a contact to edit.");
            return;
        }
        
        File file = lists.get(selectedRow);
        String name = fileName.getText();
        String phoneNumber = fileSize.getText();
        String email = fileType.getText();
        
        if (name.isEmpty()) {
            showErrorDialog("Please enter a name.");
            return;
        }
        
        if (!isValidSize(phoneNumber)) {
            showErrorDialog("Invalid phone number format.");
            return;
        }
        
        if (!isValidType(email)) {
            showErrorDialog("Invalid email format.");
            return;
        }
        
        file.setName(name);
        file.setFileSize(phoneNumber);
        file.setFileType(email);
        tableModel.setValueAt(name, selectedRow, 0);
        tableModel.setValueAt(phoneNumber, selectedRow, 1);
        tableModel.setValueAt(email, selectedRow, 2);
        clearFormFields();
    }
    
    private void refreshFile() {
        int selectedRow = fileTable.getSelectedRow();
        
        if (selectedRow == -1) {
            showErrorDialog("Please select a contact to delete.");
            return;
        }
        
        lists.remove(selectedRow);
        tableModel.removeRow(selectedRow);
        clearFormFields();
    }
    
    private void clearFormFields() {
        fileName.setText("");
        fileSize.setText("");
        fileType.setText("");
    }
    
    private void showErrorDialog(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }
    
    private boolean isValidSize(String filesize) {
        // size validation less than 100 and greater than 0
        if (filesize.isEmpty()) {
            return false;
        }
        try {
            int size = Integer.parseInt(filesize);
            return size > 0 && size < 100;
        } catch (NumberFormatException e) {
            return false;
        }
    }
    
    private boolean isValidType(String filetype) {
        // check if the file type is either pdf, doc, or txt
        if (filetype.isEmpty()) {
            return false;
        }
        if (filetype.equals("pdf") || filetype.equals("doc") || filetype.equals("txt")) {
            return true;
        }
        return true;
    }
    
    private static class File {
        private String name;
        private String fileSize;
        private String fileType;
        
        public File(String name, String fileSize, String fileType) {
            this.name = name;
            this.fileSize = fileSize;
            this.fileType = fileType;
        }
        
        public String getName() {
            return name;
        }
        
        public void setName(String name) {
            this.name = name;
        }
        
        public String getFileSize() {
            return fileSize;
        }
        
        public void setFileSize(String fileSize) {
            this.fileSize = fileSize;
        }
        
        public String getFileType() {
            return fileType;
        }
        
        public void setFileType(String fileType) {
            this.fileType = fileType;
        }
    }
    
    /**
     * Main method to run the program.
     * @param args
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new FileManagementSystem().setVisible(true);
            }
        });
    }
}